import styled from 'styled-components';

const Icons = styled.div`
margin: 0.5rem 1rem 0.2rem 0.2rem;
// background-color: red;
`;

export default Icons;
